#------------------------------
#blink_USR3
#------------------------------
#Authors: Luis Perales
#Copyright 2019, Luis Perales

import Adafruit_BBIO.GPIO as GPIO
import time

GPIO.setup("USR3", GPIO.OUT)

while True:
        GPIO.output("USR3", GPIO.HIGH)
        time.sleep(0.1)
            
        GPIO.output("USR3", GPIO.LOW)
        time.sleep(0.1)
        


    